/*
 * sv_mem.cpp
 *
 *  Created on: April 11, 2021
 *      Author: Wilburn
 */

#include "src/list_mem/sv_list.hpp"
#include "sv_mem.hpp"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <string>


std::string InnSV_GetNodeMessage(const std::string s8FileName, \
		const int s32FileLine, const std::string s8FuncName) {

	char s8Tmp[128];
	memset(s8Tmp, '\0', 128);
	sprintf(s8Tmp, "%s(line %d):%s", s8FileName.c_str(), s32FileLine, s8FuncName.c_str());
	std::string s8Msg(s8Tmp);
	return s8Msg;
}


void *SV_Malloc(const unsigned int u32Size, \
		const std::string s8FileName, \
		const int s32FileLine, \
		const std::string s8FuncName) {

	void *pAddr = malloc(u32Size);
	if ( pAddr == NULL ) {
		return NULL;
	}

//	std::string s8MemInfo = s8FileName + "(line " + s8FileLine + "):" + s8FuncName;
//	SV_MEM_NODE *pNode = MEM_MANNGER.sv_creatNode(pAddr, s8MemInfo);
	SV_MEM_NODE *pNode = MEM_MANNGER.sv_creatNode(pAddr, InnSV_GetNodeMessage(s8FileName, s32FileLine, s8FuncName));
	MEM_MANNGER.sv_insertNode(pNode);
	return pAddr;
}


void SV_Free(void* pMemAddr) {
	MEM_MANNGER.sv_removeNode(pMemAddr);
	free(pMemAddr);
}


int SV_GetMemMapSize(void) {
	return MEM_MANNGER.sv_getNodeCnt();
}



void SV_TraverseMap(void) {
	MEM_MANNGER.sv_traverseMap();
}


