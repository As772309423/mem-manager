/*
 * sv_mem.hpp
 *
 *  Created on: April 11, 2021
 *      Author: Wilburn
 */

#ifndef _SV_MEMMORY_HPP__
#define _SV_MEMMORY_HPP__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>


#define _MALLOC__(size) SV_Malloc(size,__FILE__,__LINE__,__FUNCTION__)
#define _FREE__(pmemaddr) SV_Free(pmemaddr)
#define _MEM_SIZE__ SV_GetMemMapSize()
#define _MEM_TRAVER__ SV_TraverseMap()

void *SV_Malloc(const unsigned int u32Size, \
		const std::string s8FileName, \
		const int s32FileLine, \
		const std::string s8FuncName);
void SV_Free(void* pMemAddr);
int SV_GetMemMapSize(void);
void SV_TraverseMap(void);

#endif /* _SV_MEMMORY_HPP__ */

