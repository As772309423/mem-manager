/*
 * sv_list.hpp
 *
 *  Created on: April 11, 2021
 *      Author: Wilburn
 */

#ifndef _SV_MEMMORY_LIST_HPP__
#define _SV_MEMMORY_LIST_HPP__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <string>
#include <map>

#define MEM_INFO_SIZE 64

typedef struct SV_MEM_NODE {
	void *pMemAddr;
	char s8MemInfo[MEM_INFO_SIZE];
}SV_MEM_NODE;


#define MEM_MANNGER SV_Mem_Manager::sv_getInstance()


class SV_Mem_Manager {
public:
    inline static SV_Mem_Manager& sv_getInstance(void) {
        static SV_Mem_Manager myself;
        return myself;
    }

	SV_MEM_NODE *sv_creatNode(void *pAddr, const std::string s8MemInfo);
	int sv_insertNode(SV_MEM_NODE *pDestNode);
	int sv_removeNode(void *pMemAddr);
	unsigned int sv_getNodeCnt(void);

	void sv_traverseMap(void);
	void sv_printNodeInfo(void *pMemAddr);

private:
	SV_Mem_Manager(void);
	SV_Mem_Manager(const SV_Mem_Manager&) = delete;
	SV_Mem_Manager& operator=(const SV_Mem_Manager &other) = delete;
	virtual ~SV_Mem_Manager();

private:
	std::map<void *, SV_MEM_NODE *> g_stMemMap;
};


#endif /* _SV_MEMMORY_LIST_HPP__ */
