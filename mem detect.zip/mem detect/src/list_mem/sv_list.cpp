/*
 * sv_list.hpp
 *
 *  Created on: April 11, 2021
 *      Author: Wilburn
 */


#include "sv_list.hpp"

#include <algorithm>

SV_Mem_Manager::SV_Mem_Manager(void) {
	this->g_stMemMap.clear();
}

SV_Mem_Manager::~SV_Mem_Manager() {
}


SV_MEM_NODE *SV_Mem_Manager::sv_creatNode(void *pAddr, const std::string s8MemInfo) {

	SV_MEM_NODE* pNode = (SV_MEM_NODE*)malloc(sizeof(SV_MEM_NODE));
	if ( pNode == NULL ) {
		return NULL;
	}

	pNode->pMemAddr = pAddr;
	unsigned int u32DataSize = s8MemInfo.size() > MEM_INFO_SIZE ? MEM_INFO_SIZE : s8MemInfo.size();
	memcpy(pNode->s8MemInfo, s8MemInfo.c_str(), u32DataSize);
	return pNode;
}


int SV_Mem_Manager::sv_insertNode(SV_MEM_NODE *pNewNode) {

	if ( pNewNode == NULL ) {
		return -1;
	}

	this->g_stMemMap.insert(std::pair<void *, SV_MEM_NODE*>(pNewNode->pMemAddr, pNewNode));
	return 0;
}


int SV_Mem_Manager::sv_removeNode(void *pMemAddr) {

	if ( pMemAddr == NULL ) {
		return -1;
	}

	try {
		this->g_stMemMap.at(pMemAddr);
	}
	catch (...) {
		printf("sv_removeNode : pDestNode->pMemAddr is error! pMemAddr = %p\n", pMemAddr);
		return -1;
	}

	this->g_stMemMap.erase(pMemAddr);
	return 0;
}


unsigned int SV_Mem_Manager::sv_getNodeCnt(void) {
	return this->g_stMemMap.size();
}


void SV_Mem_Manager::sv_traverseMap(void) {

	std::map<void *, SV_MEM_NODE *>::iterator iter;
	for (iter=this->g_stMemMap.begin(); iter!=this->g_stMemMap.end(); iter++) {
		printf("(addr, info) = (0x%X, %s)\n", iter->second->pMemAddr, iter->second->s8MemInfo);
	}
}


void SV_Mem_Manager::sv_printNodeInfo(void *pMemAddr) {


	if ( pMemAddr == NULL ) {
		return ;
	}

	try {
		this->g_stMemMap.at(pMemAddr);
	}
	catch (...) {
		printf("sv_printNodeInfo : pDestNode->pMemAddr is error! pMemAddr = %p\n", pMemAddr);
		return ;
	}

	SV_MEM_NODE *pNode = this->g_stMemMap.at(pMemAddr);
	printf("(addr, info) = (0x%X, %s)\n", pNode->pMemAddr, pNode->s8MemInfo);
}







