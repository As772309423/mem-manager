/*
 * sv_mem.hpp
 *
 *  Created on: April 11, 2021
 *      Author: Wilburn
 */

#include "include/sv_mem.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(void) {

	void *p[1100];

	for (int i=0; i<1100; ++i) {
		p[i] = _MALLOC__(1024);
	}

	printf("_MEM_SIZE__ = %d\n", _MEM_SIZE__);

	for (int i=0; i<1090; ++i) {
		_FREE__(p[i]);
	}


	printf("_MEM_SIZE__ = %d\n", _MEM_SIZE__);

	_MEM_TRAVER__;
	return 0;
}
